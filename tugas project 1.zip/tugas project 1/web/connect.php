<?php 
$db = mysqli_connect("localhost", "root", "", "databasekomentar");
function tambah($data){
	global $db;
	$email = $data["email"];
	$komentar = $data["komentar"];

	$info = "INSERT INTO daftarkomentar (email, komentar)
				VALUES 
			('$email', '$komentar')";
	mysqli_query($db, $info);
	return mysqli_affected_rows($db);
}


 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nandar website.com</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" type="image/jpg" sizes="16x16" href="favicon-16x16.png">
</head>

<body>
    <nav>
        <a href="index.php">Home</a> |
        <a href="contact.php">Contact</a> |
        <a href="about.php">About me</a>
    </nav>

    <hr />

    <header style="text-align: center;">
        <img src="image/gambar.jpg" width="200" height="200" style="border-radius: 50%;"/>
        <h1>Nandar</h1>
        <p>( Akun Mahasiswa)</p>
    </header>

    <hr />

    <article style="text-align: center;">
        <h2>Overview</h2>
        <p>
            Hi, saya adalah mahasiswa yang kuliah di Universitas Halu Oleo. <br>
            Ini adalah web pribadi yang di tugaskan dalam mata kuliah Pemrograman Berorientasi Objek
            selamat datang 
            welcome to my website privat now!!!!.
        </p>
    </article>
    <hr>
    <footer style="text-align: center;">
        <p>Copyright &copy; 2024 nandarwebsite.com.</p>
    </footer>
</body>
</html>
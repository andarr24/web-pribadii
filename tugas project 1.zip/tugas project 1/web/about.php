<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nandar.Website</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" type="image/jpg" sizes="16x16" href="favicon-16x16.png">
</head>

<body>
    <nav>
        <a href="index.php">Home</a> |
        <a href="contact.php">Contact</a> |
        <a href="about.php">About me</a>
    </nav>

    <hr />

    <article>
        <h1>About Me</h1>
        <p>
            Hi, saya adalah mahasiswa yang kuliah di Universitas Halu Oleo.
            Ini adalah web pribadi yang di tugaskan dalam mata kuliah Pemrograman Berorientasi Objek.
        </p>
        <p>
            Saya memang masih baru dalam wesite pribadi ini , karena itu
            saya tidak akan pernah berhenti belajar sehingga dari akun ini saya bisa 
            mengembangkan lagi kedepannya.
        </p>
        <p>
            Saya ingin menguasai bahasa HTML, CSS,sehingga dari pembuatan akun ini 
            yuk kita Simak video lengkap tentang saya.
        </p>
        <p>
            <video width= "480p" heigth = "640"controls>
                <source src="video/nandar.MP4" type="video/MP4"/>
            </video>
        </p>
    </article>

    <hr>
    <footer style="text-align: center;">
        <p>Copyright &copy; 2024 Nandarwebsite.com</p>
    </footer>
</body>
</html>
<?php 
require "connect.php";
if(isset($_POST["submit"])){
	if(tambah($_POST) > 0){
		echo"
			<script>
				alert('Pesan berhasil dikirim ke database');
			</script>
		";
	} else {
		echo "<script>
				alert('Pesan gagal dikirim ke database');
			</script>";}
}
 ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nandar website.com</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
</head>

<body>
    <nav>
        <a href="index.php">Home</a> |
        <a href="contact.php">Contact</a> |
        <a href="about.php">About me</a>
    </nav>

    <hr />

    <div>
        <h1>Contact Me</h1>
        <form action="" method="post">
            <label for="email">Email</label><br />
            <input type="email" name="email" id="email" placeholder="Alamat email"/>
            <br />
            <label for="komentar">Pesan</label><br />
            <textarea name="komentar" id="komentar" placeholder="Tulis pesan anda..." rows="4" cols="80"></textarea>
            <br />
            <br />
            <input type="submit" name="submit"value="Kirim" />
        </form>
    </div>

    <hr>
    <footer style="text-align: center;">
        <p>Copyright &copy; 2024 nandarwebsite.com.</p>
    </footer>
</body>
</html>